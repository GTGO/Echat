package com.user;

import java.util.Hashtable;

public class AllUser {
	static Hashtable usertable = new Hashtable();
	public static void add(user x)
	{
		usertable.put(x.getid(),x);
	}
	
	public static void delete(int id){
		usertable.remove(id);
	}
}
