package com.user;

public class user {
	public int id;
	public String name = "A";
	private String account = "default";
	private String password = "default";
	
	public int getid()
	{
		return id;
	}
	
	public String getname(){
		return name;
	}
	
	public void setid(int x)
	{
		id = x;
	}
	
	public void setname(String x){
		name = x;
	}
	
	public void setaccount(String x){
		account = x;
	}
	
	public void setpassword(String x){
		password = x;
	}
	
}
