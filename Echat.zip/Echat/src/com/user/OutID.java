package com.user;
public class OutID {
	public static int ID = 0;
	public static int getID(){
		return ID++;
	}
}