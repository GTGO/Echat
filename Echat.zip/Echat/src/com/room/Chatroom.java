package com.room;

import java.util.*;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.*;

import com.socket.MulWebSocket;

public class Chatroom {
	String name;
	String roomID;
	Set flag = new HashSet();
	private static CopyOnWriteArraySet<Session> webSocketSet = new CopyOnWriteArraySet<Session>();
	void addsocket(Session session){
		webSocketSet.add(session);
	}
	
	void deletesocket(Session session){
		webSocketSet.remove(session);
	}
	
	public CopyOnWriteArraySet<Session> get(){
		return webSocketSet;
	}
}
