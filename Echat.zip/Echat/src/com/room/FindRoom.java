package com.room;
import java.util.*;
public class FindRoom {
	private Hashtable id_room_table = new Hashtable();
	
	
	
}
